<?php
$pdo = new PDO('mysql:host=localhost;port=8889;dbname=misc', 
   'fred', 'zap');
?>
